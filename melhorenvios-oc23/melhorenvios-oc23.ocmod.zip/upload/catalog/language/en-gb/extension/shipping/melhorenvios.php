<?php
// Text
$_['text_title']       = 'Melhor Envio';
$_['text_description'] = 'Melhor Envio Shipping Rate';