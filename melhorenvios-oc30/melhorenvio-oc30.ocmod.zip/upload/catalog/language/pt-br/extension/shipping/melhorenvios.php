<?php
// Text
$_['text_title']       = 'Melhor Envios';
$_['text_description'] = 'Taxa de Envio';