<?php
// Text
$_['text_title']       = 'Melhor Envios';
$_['text_description'] = 'Melhor Envios Shipping Rate';