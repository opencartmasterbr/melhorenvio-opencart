<?php
// Text
$_['text_title']       = 'Melhor Envio';
$_['text_description'] = 'Taxa de Envio';